import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.JOptionPane;

    /**
     * Clase principal del simulador de apilar tazas y tapas
     * Gestiona Tower, las tazas y sus tapas, y proporciona funcionalidades
     * para apilar, ordenar y consultar información.
     *
     * version 3.0 (Ciclo 1) 
     *
     */

public class Tower {
    private int width; 
    private int height; 
    private boolean visible;
    private boolean ok;
    private boolean active; 
    
    private ArrayList<Cup> cups;
    private ArrayList<StackEntry> stack;
    private int margin;

    private TowerFrame frame;
    private static final int DEFAULT_MARGIN = 50;
    private static final String[] COLORS = {"red", "blue", "yellow", "green", "magenta"};
    private static final int PIXELS_PER_CM = 10;
    private static final int LID_HEIGHT_CM = 1; 
        
    
    
    private int colors = 0;
    private int nextId = 0;

    
    /**
     * A continuación se crea el constructor de la clase Tower 
     * Se encarga de crear una torre con width y height determinados 
     * @param width 
     * @param maxHeight 
     */
    
    public Tower(int width, int maxHeight) {
        if (width <= 0 || maxHeight <= 0) {
            ok = false;
            showMessage("Error:dimensions < 0 .");
            return;
        }
        this.width = width;
        this.height = maxHeight;
        this.visible = false;
        this.ok = true;
        this.active = true;
        this.margin = DEFAULT_MARGIN;
        
        this.cups = new ArrayList<Cup>();
        this.stack = new ArrayList<StackEntry>();
        
        this.frame = new TowerFrame(width, maxHeight, DEFAULT_MARGIN);
    }
    
    /**
     * @CICLO 2 
     * Requisito 10: Se va a crear un nuevo contructor de Tower que no incluya lids
     * Finaliza el simulador dejandolo invisible
     */
    public Tower(int cupsCount) {
        this(10, Math.max(10, cupsCount * 10));
        this.margin = 10; 
        this.frame = new TowerFrame(width, height, this.margin);
        makeInvisible();
        for (int k = 1; k <= cupsCount; k++) {
            int size = 2 * k - 1;   // 1,3,5,7,...
            pushCup(size);
        }
    }
    
    /**
     * @CICLO 2
     * Requisito 11
     * Intercambia posición de objetos entre la torre (swap)
     */
    private int numberOf(StackEntry e) {
        if (e.getType().equals("cup")) return e.getCup().getBlockSize();
        if (e.getType().equals("lid")) return e.getLid().getBlockSize();
        return -1;
    }

    private int findIndexOf(String type, int number) {
        for (int i = 0; i < stack.size(); i++) {
            StackEntry e = stack.get(i);
            if (e.getType().equals(type) && numberOf(e) == number) {
                return i;
            }
        }
        return -1;
    }
    /**
     * no permite hacer instanciamiento ya que le entra un array (toca desde terminal) 
     * se va a sobrecargar el método para le presnetación de ciclo 
     */
    public void swap(String[] o1, String[] o2) {
        if (!active) {
            showMessage("Simulator finished");
            ok = false;
            return;
        }
        
        if (o1 == null || o2 == null || o1.length < 2 || o2.length < 2) {
            showMessage("invalid objects");
            ok = false;
            return;
        }

        String t1 = o1[0];
        String t2 = o2[0];

        int n1 = Integer.parseInt(o1[1]);
        int n2 = Integer.parseInt(o2[1]);

        int i1 = findIndexOf(t1, n1);
        int i2 = findIndexOf(t2, n2);

        if (i1 == -1 || i2 == -1) {
            showMessage("object not found");
            ok = false;
            return;
        }

        StackEntry tmp = stack.get(i1);
        stack.set(i1, stack.get(i2));
        stack.set(i2, tmp);

        normalizeStack();
        repositionAllItems();
        ok = true;
    }
    
    /**
     * Swap sobrecargado para las pruebas 
     */
    public void swap(String type1, String num1, String type2, String num2) {
        swap(new String[]{type1, num1}, new String[]{type2, num2});
    }
    
    
    /**
     * @CICLO 2
     * Requisito 12
     */
    public void cover (){
        if(!active) {
            showMessage ("Simulator finished"); 
            ok = false; 
            return; 
        }
        boolean anyCovered = false;
        for (int i = 0; i < cups.size(); i++) {
            Cup cup = cups.get(i);
            if (!cup.hasLid()) {
                int currentHeight = calculateCurrentHeight();
                if (currentHeight + LID_HEIGHT_CM <= height) {
                    pushLid(i);
                    anyCovered = true;
                }
            }
        }
        if (!anyCovered) {
            showMessage("No cups to cover");
            ok = false;
            return;
        }
        ok = true;
        
    }
    
    
    /**
     * Se debe hacer +1 taza en Tower 
     * @param blockSize 
     */
    
    public void pushCup (int blockSize) {
        if (!active) {
            showMessage ("Simulator Finished"); 
            return; 
        }
        if (blockSize > width) {
            showMessage("The cup cannot be wider than the tower");
            ok = false;
            return;
        }
        int currentHeight = calculateCurrentHeight();
        if (currentHeight + blockSize > height) {
            showMessage("Tower doesn´t have enough space");
            ok = false;
            return;
        }
        String color = getNextColor();
        int id = nextId++;
        Cup cup = new Cup(color, blockSize, id);
        cups.add(cup);
        stack.add(new StackEntry(cup));
        repositionAllItems();
        
        if (visible) {
            cup.makeVisible();
        }
        ok = true;
    }
    
    /**
     * Elimina una taza usando el índice (posición) dentro de la lista cups.
     */
    public void removeCup(int index) {
        if (!active) {
            showMessage("Simulator Finished");
            return;
        }

        if (index < 0 || index >= cups.size()) {
            showMessage("invalid index.");
            ok = false;
            return;
        }

        Cup cup = cups.get(index);
        int id = cup.getId();

        if (cup.hasLid()) {
            cup.getLid().makeInvisible();
            cup.setLid(null);
        }

        cup.makeInvisible();

        cups.remove(index);

        for (int i = stack.size() - 1; i >= 0; i--) {
            if (stack.get(i).getCupId() == id) {
                stack.remove(i);
            }
        }

        repositionAllItems();
        ok = true;
    }
    
    private String getNextColor() {
        String c = COLORS[colors % COLORS.length];
        colors++;
        return c;
    }
    
    
    private void repositionAllItems() {
    if (!visible) {
        return;
    }

    int xLeft = margin;
    int yTop = margin;

    int towerInnerWidthPx = width * PIXELS_PER_CM;
    int towerInnerHeightPx = height * PIXELS_PER_CM;

    int floorY = yTop + towerInnerHeightPx;
    int currentBottom = floorY;

    for (StackEntry e : stack) {
        if (currentBottom < yTop) {
            break;
        }

        switch (e.getType()) {
            case "cup": {
                Cup cup = e.getCup();
                int cupHeightPx = cup.getBlockSize() * PIXELS_PER_CM;
                int cupWidthPx = cup.getWidth();
                int yCupTop = currentBottom - cupHeightPx;
                int xCup = xLeft + (towerInnerWidthPx - cupWidthPx) / 2;
                cup.setupRectangle(xCup, yCupTop, cupWidthPx);
                currentBottom = yCupTop;
                break;
            }
            
            
            
            case "lid": {
                Lid lid = e.getLid();
                int lidHeightPx = LID_HEIGHT_CM * PIXELS_PER_CM;
                int lidWidthPx = lid.getWidthPx();
                int yLidTop = currentBottom - lidHeightPx;
                int xLid = xLeft + (towerInnerWidthPx - lidWidthPx) / 2;
                lid.setupRectangle(xLid, yLidTop, lidWidthPx);
                currentBottom = yLidTop;
                break;
            }
            default:
                break;
            }
        }
    }   
    
    
    private void normalizeStack() {
        ArrayList<StackEntry> newStack = new ArrayList<StackEntry>();

        for (StackEntry e : stack) {
            if (e.getType().equals("cup")) {
                Cup cup = e.getCup();
                newStack.add(e);
                if (cup != null && cup.hasLid()) {
                    Lid lid = cup.getLid();
                    newStack.add(new StackEntry(lid, cup.getId()));
                }
            }
        }

        stack = newStack;
    }   
    
    /**
     * swapToReduce 
     * 
     *Consulta el intercambio de dos objetos en el stack que produzca
     * la mayor reducción de altura de la torre, sin ejecutar el intercambio.
     * Prueba todos los pares posibles de objetos en el stack, simula el swap
     * de cada par, calcula la altura resultante y retorna el par cuyo
     * intercambio genera la mayor reducción.
     * si ningun intercambio reduce altura retorna null
     */
    public String[][] swapToReduce() {
        if (!active) {
            showMessage("Simulator finished");
            ok = false;
            return null;
        }
        normalizeStack();
        int currentHeight = calculateCurrentHeight();
        int bestReduction = 0;
        int bestI = -1;
        int bestJ = -1;

        for (int i = 0; i < stack.size(); i++) {
            for (int j = i + 1; j < stack.size(); j++) {
                StackEntry tmp = stack.get(i);
                stack.set(i, stack.get(j));
                stack.set(j, tmp);
                normalizeStack();
                int newHeight = calculateCurrentHeight();
                int reduction = currentHeight - newHeight;
                tmp = stack.get(i);
                stack.set(i, stack.get(j));
                stack.set(j, tmp);
                normalizeStack();
                if (reduction > bestReduction) {
                    bestReduction = reduction;
                    bestI = i;
                    bestJ = j;
                }
            }
        }

        if (bestI == -1) {
            showMessage("No swap reduces height");
            ok = false;
            return null;
        }

        StackEntry e1 = stack.get(bestI);
        StackEntry e2 = stack.get(bestJ);
            String type1 = e1.getType();
            String num1 = type1.equals("cup") ? 
            String.valueOf(e1.getCup().getBlockSize()) : 
            String.valueOf(e1.getLid().getBlockSize());
        String type2 = e2.getType();
        String num2 = type2.equals("cup") ? 
            String.valueOf(e2.getCup().getBlockSize()) : 
            String.valueOf(e2.getLid().getBlockSize());

            ok = true;
            return new String[][] {{type1, num1}, {type2, num2}};
    }
    
    /**
     * Elimina la tapa que está en la parte de arriba del stack 
     */
    public void popLid() {
        if (!active) {
            showMessage("Simulator finished");
            ok = false;
            return;
        }
        for (int i = stack.size() - 1; i >= 0; i--) {
            if (stack.get(i).getType().equals("lid")) {
                Lid lid = stack.get(i).getLid();
                int cupId = stack.get(i).getCupId();
                Cup cup = findCupById(cupId);
                if (cup != null) {
                    removeLid(cups.indexOf(cup));
                }
                ok = true;
                return;
            }
        }
        showMessage("No lids in tower");
        ok = false;
    }
    
    
    
    
        
    /**
    *popCup 
    */
    public void popCup() {
    if (!active) {
        showMessage("Simulator finished");
        ok = false;
        return;
    }
    for (int i = stack.size() - 1; i >= 0; i--) {
        if (stack.get(i).getType().equals("cup")) {
            Cup cup = stack.get(i).getCup();
            removeCup(cups.indexOf(cup));
            ok = true;
            return;
        }
    }
    showMessage("No cups in tower");
    ok = false;
    }



    /**
     * Para eliminar una taza
     * @param index hace referencia al índice de la taza
     */

    public void removeLid(int cupIndex) {
    if (!active) {
        showMessage("Simulator finished");
        return;
    }

    if (cupIndex < 0 || cupIndex >= cups.size()) {
        showMessage("invalid index");
        ok = false;
        return;
    }

    Cup cup = cups.get(cupIndex);

    if (!cup.hasLid()) {
        showMessage("cup has no lid");
        ok = false;
        return;
    }

    int id = cup.getId();

    Lid lid = cup.getLid();
    lid.makeInvisible();
    cup.setLid(null);

    for (int i = stack.size() - 1; i >= 0; i--) {
        StackEntry e = stack.get(i);
        if (e.getType().equals("lid") && e.getCupId() == id) {
            stack.remove(i);
            break;
        }
    }

    repositionAllItems();
    ok = true;
    }
       
    
    /**
     * Para poner tapas en una taza 
     * @param cupIndex 
     */

    public void pushLid(int cupIndex) {
    if (!active) {
        showMessage("Simulator Finished");
        return;
    }
    if (cupIndex < 0 || cupIndex >= cups.size()) {
        showMessage("invalid cup index");
        ok = false;
        return;
    }
    Cup cup = cups.get(cupIndex);
    if (cup.hasLid()) {
        showMessage("cup has already lid");
        ok = false;
        return;
    }
    int currentHeight = calculateCurrentHeight();
    if (currentHeight + LID_HEIGHT_CM > height) {
        showMessage("Not enough space to lid");
        ok = false;
        return;
    }
    int id = cup.getId();
    Lid lid = new Lid(cup.getColor(), cup.getBlockSize(), id);
    cup.setLid(lid);

    int insertPos = -1;
    for (int i = 0; i < stack.size(); i++) {
        if (stack.get(i).getType().equals("cup") && stack.get(i).getCupId() == id) {
            insertPos = i + 1;
            break;
        }
    }
    if (insertPos == -1) {
        stack.add(new StackEntry(lid, id));
    } else {
        stack.add(insertPos, new StackEntry(lid, id));
    }

    if (visible) {
        lid.makeVisible();
    }
    repositionAllItems();
    ok = true;
    }

    
    

    

    
    /**
     * Invertir el orden de la torre
     * Se nornmaliza antes y después para que la tapa quede pegada a la taza 
     */
    public void reverseTower() {
        if (!active) {
            showMessage("Simulator finished");
            ok = false;
            return;
        }

        normalizeStack();
        Collections.reverse(stack);
        normalizeStack();

        repositionAllItems();
        ok = true;
    }
    
    private Cup findCupById(int id) {
    for (Cup cup : cups) {
        if (cup.getId() == id) {
            return cup;
        }
    }
    return null;
    }
    
    private int calculateCurrentHeight() {
        int total = 0;
        for (StackEntry e : stack) {
            total += e.heightCm();
        }
        return total;
    }
    
    /**
     * Ordena la torre de mayor a menor con las fichas que caben 
     */
    public void orderTower() {
        if (!active) {
            showMessage("Simulator finished");
            ok = false;
            return;
        }

        normalizeStack();

        Collections.sort(stack, (a, b) -> {
            int na = (a.getType().equals("cup")) ? a.getCup().getBlockSize() : a.getLid().getBlockSize();
            int nb = (b.getType().equals("cup")) ? b.getCup().getBlockSize() : b.getLid().getBlockSize();
            return Integer.compare(nb, na);
        });

        normalizeStack();
        repositionAllItems();
        ok = true;
    }
    /**
     * h total 
     * 
     */
    public int height() {
        return calculateCurrentHeight();
    }
    
    /**
     * Método para hallar las tazas tapadas (se identifican con el id)
     */
    public int[] liddedCups() {
        
    ArrayList<Integer> sizes = new ArrayList<Integer>();
    for (Cup cup : cups) {
        if (cup.hasLid()) {
            sizes.add(cup.getBlockSize());
        }
    }
    Collections.sort(sizes);
    int[] r = new int[sizes.size()];
    for (int i = 0; i < sizes.size(); i++) r[i] = sizes.get(i);
    return r;
    }
    
    /**
     * De abajo hacia arriba retorna type y numero
     */
    public String[][] stackingItems() {
        normalizeStack();

        ArrayList<String[]> out = new ArrayList<String[]>();
        for (StackEntry e : stack) {
            if (e.getType().equals("cup")) {
                out.add(new String[]{"cup", String.valueOf(e.getCup().getBlockSize())});
            } else if (e.getType().equals("lid")) {
                out.add(new String[]{"lid", String.valueOf(e.getLid().getBlockSize())});
            }
        }

        String[][] r = new String[out.size()][2];
        for (int i = 0; i < out.size(); i++) r[i] = out.get(i);
        return r;
    }
    
    public void makeVisible() {
        visible = true;
        frame.makeVisible();

        for (Cup cup : cups) {
            cup.makeVisible();
            if (cup.hasLid()) {
                cup.getLid().makeVisible();
            }
        }

        repositionAllItems();
        ok = true;
    }

    public void makeInvisible() {
        visible = false;

        for (Cup cup : cups) {
            cup.makeInvisible();
            if (cup.hasLid()) {
                cup.getLid().makeInvisible();
            }
        }

        frame.makeInvisible();
        ok = true;
    }
    
    /**
     * Booleano que dice si la ultima operación fue exitosa o no 
     */
    public boolean ok() {
        return ok; 
    }
    
    

        /**
     * Muestra un mensaje al usuario si el simulador es visible.
     * @param message el mensaje a mostrar
     */
    private void showMessage(String message) {
        if (visible) {
            JOptionPane.showMessageDialog(null, message, 
                "StackingItems Simulator", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    /**
     * Termina el simulador 
     */
    public void exit() {
        active = false;
        makeInvisible();
        ok = true;
    }
    
   
}

    

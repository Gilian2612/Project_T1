import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class TowerUnitTest.
 *
 * @author  William Santiago Ruiz Medina
 * @version 5
 */
public class TowerUnitTest
{
    
    private void assertEqualsInt(int expected, int actual, String msg) {
        if (expected != actual) throw new RuntimeException(msg + " expected=" + expected + " actual=" + actual);
    }
    
    private int countType(String[][] arr, String type) {
        int c = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i][0].equals(type)) c++;
        }
        return c;
    }

    
    @Test
    public void shouldCreateTower() {
        Tower t = new Tower(10, 30);
        assertTrue(t != null, "shouldCreateTower");
    }
    
    @Test
    public void shouldAddCupAndIncreaseHeight() {
        Tower t = new Tower(10, 30);
        t.makeInvisible();
        int h0 = t.height();
        t.pushCup(3);
        assertEqualsInt(h0 + 3, t.height(), "shouldAddCupAndIncreaseHeight");
    }
    
    @Test
    public void shouldRemoveCupAndDecreaseHeight() {
        Tower t = new Tower(10, 30);
        t.makeInvisible();
        t.pushCup(3);
        t.pushCup(4);
        int h0 = t.height();
        t.removeCup(0);
        assertEqualsInt(h0 - 3, t.height(), "shouldRemoveCupAndDecreaseHeight");
    }
    
    @Test
    public void shouldAddLidAndIncreaseHeightByOne() {
        Tower t = new Tower(10, 30);
        t.makeInvisible();
        t.pushCup(5);
        int h0 = t.height();
        t.pushLid(0);
        assertEqualsInt(h0 + 1, t.height(), "shouldAddLidAndIncreaseHeightByOne");
        assertTrue(countType(t.stackingItems(), "lid") == 1, "shouldAddLidAndIncreaseHeightByOne lid exists");
    }



    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}

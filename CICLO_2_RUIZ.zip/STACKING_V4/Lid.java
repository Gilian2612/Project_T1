/**
 * Representa una tapa en el simulador de apilamiento.
 * La tapa mide 1 cm de alto y debe moverse/posicionarse alineada en la torre.
 */
public class Lid {
    private static final int LID_HEIGHT_CM = 1;
    private static final int PIXELS_PER_CM = 10;

    private String color;
    private int blockSize;     
    private final int id;
    private boolean visible;
    private Rectangle rectangle;

    public Lid(String color, int blockSize, int id) {
        this.color = color;
        this.blockSize = blockSize;
        this.id = id;
        this.visible = false;
        this.rectangle = new Rectangle();
    }

    public void makeVisible() {
        visible = true;
        if (rectangle != null) {
            rectangle.makeVisible();
        }
    }

    public void makeInvisible() {
        visible = false;
        if (rectangle != null) {
            rectangle.makeInvisible();
        }
    }

    public String getColor() {
        return color;
    }

    public int getId() {
        return id;
    }

    public int getBlockSize() {
        return blockSize;
    }

    public int getHeightCm() {
        return LID_HEIGHT_CM;
    }

    public int getWidthPx() {
        return blockSize * PIXELS_PER_CM;
    }

    public void moveTo(int x, int y) {
        if (rectangle != null) {
            rectangle.moveTo(x, y);
        }
    }

    /**
     * rectángulo visual de la tapa.
     * @param x esquina superior izq
     * @param y esquina superior izq
     * @param widthPx ancho 
     */
    public void setupRectangle(int x, int y, int widthPx) {
        int heightPx = LID_HEIGHT_CM * PIXELS_PER_CM;
        rectangle.changeSize(heightPx, widthPx);
        rectangle.changeColor(color);
        rectangle.moveTo(x, y);

        if (visible) {
            rectangle.makeVisible();
        }
    }
}